import { httpRouter } from "convex/server";

const http = httpRouter();

// يمكن إضافة HTTP endpoints هنا لاحقاً لـ API الخارجي

export default http;
